library(dplyr)
library(readr)
library(brms)
library(lme4)

##IMPORT DATA FOR STUDIES 1 and 2
hp.df <- read_csv("hp.df.csv")
rating.sc.scores <- read_csv("rating.sc.scores.csv")
rating.rl.scores <- read_csv("rating.rl.scores.csv")
text.sc.scores <- read_csv("text.sc.scores.csv")
prev.scores <- read_csv("prev.scores.csv")

hp.df <- hp.df %>% 
  merge(rating.rl.scores, by="illness")  %>% 
  merge(rating.sc.scores, by="illness") %>% 
  merge(text.sc.scores, by="illness") %>% 
  merge(prev.scores, by="illness")


###STUDY 1 ANALYSES 

##Effect of news.type on Shares
b1 <- brm(Shares ~ news.type.num + (news.type.num|Page.Name), hp.df, iter=3000, 
          cores = 4, family = negbinomial(), file="mhm.b1")

#similar model with lmer 
lm1 <- lmer(log(Shares+1) ~ news.type.num + (1|Page.Name), hp.df)


##Effect of news.type on Shares with all covariates 
b1.cov.form<-as.formula(paste0("Shares ~ 
  news.type.num + 
  audience_size + 
  hour + wday + month + year + 
  prev + relevance + 
  me + posemo + negemo +
  ",  paste0("topic",seq(1:309), collapse="+"), "+ (news.type.num|Page.Name)"))

b1.cov <- brm(formula=b1.cov.form, hp.df, iter=3000, cores = 4,
              family = negbinomial(), file="mhm.b1.cov")


#similar model with lmer 
lm1.cov.form<-as.formula(paste0("log(Shares+1) ~ 
  news.type.num + 
  audience_size + 
  hour + wday + month + year + 
  prev + relevance + 
  me + posemo + negemo +
  ",  paste0("topic",seq(1:309), collapse="+"), "+ (1|Page.Name)"))

lm1.cov <- lmer(lm1.cov.form, hp.df)


###STUDY 2 ANALYSES

##assess effects of illness type on stereotype scores 

b.rating.comp <- brm(competence ~ illness.type, rating.sc.scores, 
                     cores=4,iter=3000)
b.rating.warm <- brm(warmth ~ illness.type, rating.sc.scores,
                     cores=4,iter=3000)
b.text.comp <- brm(compdiff ~ illness.type, text.sc.scores,
                   cores=4,iter=3000)
b.text.warm <- brm(warmdiff ~ illness.type, text.sc.scores,
                   cores=4,iter=3000)

#similar models with lm
lm.rating.comp <- lm(competence ~ illness.type, rating.sc.scores)
lm.rating.warm <- lm(warmth ~ illness.type, rating.sc.scores)
lm.text.comp <- lm(compdiff ~ illness.type, text.sc.scores)
lm.text.warm <- lm(warmdiff ~ illness.type, text.sc.scores)


##assess mediation by competence 
##ratings-based measure
a_path <- bf(competence ~ news.type.num + (news.type.num|ID|Page.Name))
b_path<- bf(Shares ~ news.type.num + competence + (news.type.num|ID|Page.Name), family = negbinomial())
med1.rating.out <- brm(a_path + b_path + set_rescor(FALSE), hp.df, cores=4, chains = 4, iter=3000, file="mhm.med1.rating.out")

#similar models with lmer
lm.med1.r.a_path <- lmer(competence ~ news.type.num + (1|Page.Name), hp.df)
lm.med1.r.b_path<- lmer(log(Shares+1) ~ news.type.num + competence + (1|Page.Name), hp.df)

##text-based measure 
a_path <- bf(compdiff ~ news.type.num + (news.type.num|ID|Page.Name))
b_path<- bf(Shares ~ news.type.num + compdiff + (news.type.num|ID|Page.Name),family = negbinomial())
med1.text.out <- brm(a_path + b_path + set_rescor(FALSE), hp.df, cores=4, chains = 4, iter=3000, file="mhm.med1.text.out")

#similar models with lmer
lm.med1.t.a_path <- lmer(compdiff ~ news.type.num + (1|Page.Name), hp.df)
lm.med1.t.b_path<- lmer(log(Shares+1) ~ news.type.num + compdiff + (1|Page.Name), hp.df)


##ratings with warmth as parallel mediator
a1_path <- bf(competence ~ news.type.num +  (news.type.num|ID|Page.Name))
a2_path  <- bf(warmth ~ news.type.num + (news.type.num|ID|Page.Name))
b1b2_path<- bf(Shares ~ news.type.num + competence + warmth + (news.type.num|ID|Page.Name),family = negbinomial())
med1.rating.out.warmth <- brm(a1_path + a2_path + b1b2_path + set_rescor(FALSE), hp.df, cores=4, chains = 4, iter=3000, file="mhm.med1.rating.out.warmth")

#similar models with lmer
lm.med1.r.a1_path <- lmer(competence ~ news.type.num + (1|Page.Name), hp.df)
lm.med1.r.a2_path <- lmer(warmth ~ news.type.num + (1|Page.Name), hp.df)
lm.med1.r.b1b2_path <- lmer(log(Shares+1) ~ news.type.num + competence + warmth + (1|Page.Name), hp.df)


##text with warmth as parallel mediator
a1_path <- bf(compdiff ~ news.type.num + (news.type.num|ID|Page.Name))
a2_path  <- bf(warmdiff ~ news.type.num + (news.type.num|ID|Page.Name))
b1b2_path<- bf(Shares ~ news.type.num + compdiff + warmdiff + (news.type.num|ID|Page.Name),family = negbinomial())
med1.text.out.warmth <- brm(a1_path + a2_path + b1b2_path + set_rescor(FALSE), hp.df, cores=4, chains = 4, iter=3000, file="mhm.med1.text.out.warmth")

#similar models with lmer
lm.med1.t.a1_path <- lmer(compdiff ~ news.type.num + (1|Page.Name), hp.df)
lm.med1.t.a2_path <- lmer(warmdiff ~ news.type.num + (1|Page.Name), hp.df)
lm.med1.t.b1b2_path <- lmer(log(Shares+1) ~ news.type.num + compdiff + warmdiff + (1|Page.Name), hp.df)


##rating with all covariates
a_path<-bf(paste0("competence ~ 
  news.type.num + 
  audience_size + 
  hour + wday + month + year + 
  prev + relevance + 
  me + posemo + negemo +
  ",  paste0("topic",seq(1:309), 
             collapse="+"), "+ (news.type.num|ID|Page.Name)"))

b_path<-bf(paste0("Shares ~ 
  news.type.num + 
  warmth + competence +
  audience_size + 
  hour + wday + month + year + 
  prev + relevance + 
  me + posemo + negemo +", paste0("topic",seq(1:309), collapse="+"), "+ (news.type.num|ID|Page.Name)"),family = negbinomial())

med1.rating.out.cov <- brm(a_path + b_path + set_rescor(FALSE), hp.df, cores=4, chains = 4, iter=3000, file="mhm.med1.rating.out.cov")

#similar models with lmer
lm.med1.r.a_path.cov.form<-as.formula(paste0("competence ~ 
  news.type.num + 
  audience_size + 
  hour + wday + month + year + 
  prev + relevance + 
  me + posemo + negemo +
  ",  paste0("topic",seq(1:309), collapse="+"), "+ (1|Page.Name)"))

lm.med1.r.a_path.cov <- lmer(lm.med1.r.a_path.cov.form, hp.df)

lm.med1.r.b_path.cov.form<-as.formula(paste0("log(Shares+1) ~ 
  news.type.num + 
  audience_size + 
  warmth + competence +
  hour + wday + month + year + 
  prev + relevance + 
  me + posemo + negemo +
  ",  paste0("topic",seq(1:309), collapse="+"), "+ (1|Page.Name)"))

lm.med1.r.b_path.cov <- lmer(lm.med1.r.b_path.cov.form, hp.df)


##text with all covariates
a_path<-bf(paste0("compdiff ~ 
  news.type.num + 
  audience_size + 
  hour + wday + month + year + 
  prev + relevance + 
  me + posemo + negemo +
  ",  paste0("topic",seq(1:309), collapse="+"), "+ (news.type.num|ID|Page.Name)"))

b_path<-bf(paste0("Shares ~ 
  news.type.num + 
  warmdiff + compdiff +
  audience_size + 
  hour + wday + month + year + 
  prev + relevance + 
  me + posemo + negemo +",
                  paste0("topic",seq(1:309), collapse="+"), "+ (news.type.num|ID|Page.Name)"),family = negbinomial())

med1.text.out.cov <- brm(a_path + b_path + set_rescor(FALSE), hp.df, cores=4, chains = 4, iter=3000, file="mhm.med1.text.out.cov")

#similar models with lmer
lm.med1.t.a_path.cov.form<- as.formula(paste0("compdiff ~
  news.type.num + 
  audience_size + 
  hour + wday + month + year + 
  prev + relevance + 
  me + posemo + negemo +
  ",  paste0("topic",seq(1:309), collapse="+"), "+ (1|Page.Name)"))

lm.med1.t.a_path.cov <- lmer(lm.med1.t.a_path.cov.form, hp.df)  
  

lm.med1.t.b_path.cov.form<- as.formula(paste0("log(Shares+1) ~
  compdiff + warmdiff + 
  news.type.num + 
  audience_size + 
  hour + wday + month + year + 
  prev + relevance + 
  me + posemo + negemo +
  ",  paste0("topic",seq(1:309), collapse="+"), "+ (1|Page.Name)"))

lm.med1.t.b_path.cov <- lmer(lm.med1.t.b_path.cov.form, hp.df)  

###Study 3

##import study 3 data
mhm.s3 <- read_csv("mhm.study3.csv")

##Analyses

##main effect of intervention
b3 <- brm(sharing ~ competence_hilo_num + (competence_hilo_num|ID|responseid), mhm.s3, cores=4, chains = 4, iter=3000, file="mhm.b3")

#similar model with lmer
lm3 <- lmer(sharing ~ competence_hilo_num + (competence_hilo_num|responseid), mhm.s3)

##mediation by competence
a_path <- bf(competence ~ competence_hilo_num + (competence_hilo_num|ID|responseid))
b_path <- bf(sharing ~ competence_hilo_num + competence + (competence_hilo_num + competence |ID|responseid))
med3 <- brm(a1_path + b1_path + set_rescor(FALSE), mhm.s3, cores=4, chains = 4, iter=3000, file="mhm.med3")

#similar models with lmer
lm.med3.a_path <- lmer(competence ~ competence_hilo_num + (competence_hilo_num|responseid), mhm.s3)
lm.med3.b_path <- lmer(sharing ~ competence_hilo_num + competence + (competence_hilo_num|responseid), mhm.s3)


##effect of intervention on interest 
i3 <- brm(interest ~ competence_hilo_num + (competence_hilo_num|ID|responseid), mhm.s3, cores=4, chains = 4, iter=3000, file="mhm.i3")

#similar model with lmer
lm.i3 <- lmer(interest ~ competence_hilo_num + (competence_hilo_num|responseid), mhm.s3)

##mediation controlling for interest and warmth 
a_path <- bf(competence ~ competence_hilo_num + interest + warmth + (competence_hilo_num|ID|responseid))
b_path<- bf(sharing ~ competence_hilo_num + competence + interest + warmth +(competence_hilo_num + competence |ID|responseid))
med3.cov <- brm(a_path + b_path + set_rescor(FALSE), mhm.s3, cores=4, chains = 4, iter=3000, file="mhm.med3.cov")

#similar models with lmer
lm.med3.a_path.cov <- lmer(competence ~ competence_hilo_num + interest + warmth + (competence_hilo_num|responseid), mhm.s3)
lm.med3.b_path.cov <- lmer(sharing ~ competence_hilo_num + competence + interest + warmth +  (competence_hilo_num|responseid), mhm.s3)

##mediation with warmth as a parallel mediator 
a1_path <- bf(competence ~ competence_hilo_num + (competence_hilo_num|ID|responseid))
a2_path <- bf(warmth ~ competence_hilo_num + (competence_hilo_num|ID|responseid))
b1b2_path<- bf(sharing ~ competence_hilo_num + competence + interest + warmth + (competence_hilo_num + competence + warmth |ID|responseid))
med3.parallel <- brm(a1_path + a2_path + b1b2_path + set_rescor(FALSE), mhm.s3, cores=4, chains = 4, iter=3000, file="mhm.med3.cov")


#similar models with lmer
lm.med3.a1_path <- lmer(competence ~ competence_hilo_num + (competence_hilo_num|responseid), mhm.s3)
lm.med3.a2_path <- lmer(warmth ~ competence_hilo_num + (competence_hilo_num|responseid), mhm.s3)
lm.med3.b1b2_path <- lmer(sharing ~ competence_hilo_num + competence + warmth + (competence_hilo_num|responseid), mhm.s3)


###Supplementary Materials replication & extension of Study 3

##Import study 3 extension data
mhm.s3.ext <- read_csv("mhm.study3.ext.csv")


##Analyses

##effects of intervention, illness type, and their interaction 
b3e <- brm(sharing ~ illness_type_num*competence_hilo_num  + (illness_type_num*competence_hilo_num |ID|responseid), mhm.s3.ext, cores=4, chains = 4, iter=3000, file="mhm.b3e")

#similar model with lmer
lm3e <- lmer(sharing ~ illness_type_num*competence_hilo_num + (illness_type_num*competence_hilo_num|responseid), mhm.s3.ext)


##effect of intervention on valence
b3e.val <- brm(valence ~ illness_type_num*competence_hilo_num  + (illness_type_num*competence_hilo_num |ID|responseid), mhm.s3.ext, cores=4, chains = 4, iter=3000, file="mhm.b3e.val")

#similar model with lmer
lm3e.val <- lmer(valence ~ illness_type_num*competence_hilo_num + (illness_type_num*competence_hilo_num|responseid), mhm.s3.ext)

##mediation controlling for interest, warmth, and valence 
a_path <- bf(competence ~ competence_hilo_num + interest + warmth + valence +(competence_hilo_num|ID|responseid))
b_path<- bf(sharing ~ competence_hilo_num + competence + interest + warmth + valence + (competence_hilo_num + competence |ID|responseid))
med3e.cov <- brm(a_path + b_path + set_rescor(FALSE), mhm.s3.ext, cores=4, chains = 4, iter=3000, file="mhm.med3e.cov")

#similar models with lmer
lm.med3e.a_path.cov <- lmer(competence ~ competence_hilo_num + interest + warmth + valence + (competence_hilo_num|responseid), mhm.s3.ext)
lm.med3e.b_path.cov <- lmer(sharing ~ competence_hilo_num + competence + interest + warmth + valence + (competence_hilo_num|responseid), mhm.s3.ext)




